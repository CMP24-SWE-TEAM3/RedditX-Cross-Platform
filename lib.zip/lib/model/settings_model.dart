import 'package:flutter/material.dart';

bool? hasPassword = false;
